import React from 'react';
import './App.css';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      header: 'Header...',
      content: 'Content...',
      data:0
    };
    this.setNewData = this.setNewData.bind(this);
  }
  setNewData() {
    this.setState({data : this.state.data + 1});
  }
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <div>{this.state.header}</div>
          <div>{this.state.content}</div>
          <div>{this.props.header}</div>
          <div>{this.props.content}</div>
        </header>
        <button onClick= {this.setNewData}>Increment</button>
        <Content myNumber = {this.state.data}></Content>
      </div>
    );
  }
}
class Content extends React.Component{
  componentWillMount(){
    console.log("componentWillMount");
  }
  componentWillUpdate(){
    console.log("componentWillUpdate");
  }
  componentWillReceiveProps(newProps){
    console.log("componentWillReceiveProps"); 
  }
  componentDidMount() {
    console.log("componentDidMount");
  }
  componentDidUpdate(){
    console.log("componentDidUpdate");
  }
  componentWillUnmount(){
    console.log("componentWillUnmount");
  }
  shouldComponentUpdate(newProps, oldProps){
    return true;
  }
  render() {
    return (
        <div>{this.props.myNumber}</div>
    )
}
}

export default App;
